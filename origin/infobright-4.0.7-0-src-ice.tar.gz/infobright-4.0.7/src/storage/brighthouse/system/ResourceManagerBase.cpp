#include "ResourceManagerBase.h"

ResourceManagerBase::~ResourceManagerBase()
{
	
}
