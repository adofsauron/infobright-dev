#include "RoughValue.h"

RoughValue::RoughValue(_int64 min, _int64 max) : min(min), max(max)
{
}
