
#include "system/IBLicense.h"

const char* EXPIRATION_MESSAGE = "";
